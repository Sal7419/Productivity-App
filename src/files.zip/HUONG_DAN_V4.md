# 🚀 Chance Productivity v4 — Hướng dẫn đầy đủ

## Tính năng mới trong v4

| Tính năng | Mô tả |
|---|---|
| 🏠 Trang chủ | Dashboard, check-in habit hàng ngày |
| #️⃣ Hashtag | Gắn tag cho task, lọc theo hashtag |
| ✏️ Sửa task | Chỉnh sửa bất kỳ trường nào sau khi tạo |
| 📊 Thanh tiến độ | Chạy từ ngày tạo đến deadline, animation giận khi sắp hết hạn |
| 🔥 Sửa/xóa habit | Hover để hiện nút sửa tên và xóa habit |
| ⏱️ Tùy chỉnh Pomodoro | Nhấn icon zap → chỉnh thời gian focus/nghỉ |
| 📦 Auto-archive Kanban | Khi done ≥ 10 task → tự lưu trữ, xem lại được |
| 📅 Calendar chi tiết | Click vào ngày → hiện task có deadline ngày đó |
| 🎨 Màu accent | Chọn 5 màu chủ đạo trong sidebar |
| ☁️ Đồng bộ tài khoản | Tạo tài khoản → sync đa thiết bị |

---

## Cài đặt từ đầu

### 1. Yêu cầu
- **Node.js v18+** — tải tại https://nodejs.org (chọn LTS)

### 2. Cài dependencies
```bash
cd chance-productivity
npm install
```

### 3. Thay file
Thay thế 2 file vào đúng vị trí:
```
App.tsx   →  src/App.tsx
server.ts →  server.ts   (gốc thư mục, không phải trong src)
```

### 4. Chạy app
```bash
npm run dev
```
Mở **http://localhost:3000** trên laptop.

---

## 📱 Dùng trên điện thoại (cùng WiFi)

### Bước 1 — Tìm IP của laptop

**Mac/Linux:**
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
# Tìm dòng: inet 192.168.x.x
```

**Windows (PowerShell):**
```powershell
ipconfig
# Tìm: IPv4 Address: 192.168.x.x
```

### Bước 2 — Đảm bảo `vite.config.ts` có `host: true`

Mở `vite.config.ts`, thêm `host: true` vào `server`:

```ts
server: {
  host: true,      // ← thêm dòng này
  hmr: process.env.DISABLE_HMR !== 'true',
},
```

> **Lưu ý:** File `server.ts` mới đã tự động set `host: true` cho Vite rồi, bạn chỉ cần đảm bảo `vite.config.ts` cũng có.

### Bước 3 — Truy cập từ điện thoại

Trên điện thoại, mở Chrome/Safari và vào:
```
http://192.168.x.x:3000
```
(thay bằng IP thực của laptop bước 1)

### Bước 4 — Thêm vào màn hình chính

- **iPhone (Safari):** Nhấn nút Share → "Add to Home Screen" → Add
- **Android (Chrome):** Menu 3 chấm → "Add to Home screen" → Add

App sẽ chạy toàn màn hình như ứng dụng thật!

---

## ☁️ Đồng bộ đa thiết bị (tài khoản)

Hệ thống đồng bộ hoạt động theo mô hình **laptop làm server, điện thoại là client**.

### Cách dùng

1. Chạy `npm run dev` trên laptop
2. Mở app trên điện thoại qua `http://192.168.x.x:3000`
3. Trong **sidebar** (laptop) hoặc **menu** (điện thoại) → nhấn "Đồng bộ đa thiết bị"
4. Chọn **Tạo tài khoản** → nhập email + mật khẩu → Tạo
5. Trên thiết bị thứ 2: Đăng nhập cùng email/mật khẩu → Đồng bộ ngay

**Dữ liệu đồng bộ bao gồm:** Tasks, Habits, Finance, Settings, Archive.

### Cách hoạt động

```
Laptop (Server)          Điện thoại / Laptop 2
     │                         │
     │ ← POST /api/sync        │  Tự động push mỗi 2 giây
     │                         │  khi dữ liệu thay đổi
     │ → GET  /api/sync        │  Pull khi đăng nhập
     │                         │
  .chance-db.json              │  (dữ liệu lưu ở laptop)
```

Dữ liệu tài khoản được lưu tại `.chance-db.json` trong thư mục dự án. File này tự tạo khi có người đăng ký lần đầu.

---

## 🌐 Đồng bộ khác WiFi (không cùng mạng)

Nếu muốn dùng từ xa (không cùng WiFi), có 2 cách:

### Cách A — ngrok (miễn phí, tạm thời)

1. Tải ngrok: https://ngrok.com/download
2. Chạy: `ngrok http 3000`
3. Sẽ có URL dạng `https://abc123.ngrok.io`
4. Dùng URL đó thay cho `localhost:3000` trên thiết bị khác

> URL ngrok thay đổi mỗi lần chạy (bản free). Upgrade lên Free có thể đặt tên cố định.

### Cách B — Deploy lên Render/Railway (vĩnh viễn, miễn phí)

Đây là cách tốt nhất cho sync thực sự:

1. Tạo account tại https://render.com
2. Push code lên GitHub
3. Tạo "Web Service" trên Render, trỏ vào repo
4. Set build command: `npm install && npm run build`
5. Set start command: `NODE_ENV=production node dist/server.js`
6. Thêm biến môi trường: `PORT=10000`

---

## 🎨 Favicon / Logo app (index.html)

Để đặt icon cho app khi thêm vào màn hình điện thoại, sửa `index.html`:

```html
<head>
  <link rel="icon" href="/icon.png" />
  <link rel="apple-touch-icon" href="/icon.png" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-title" content="Chance" />
  <meta name="theme-color" content="#000000" />
</head>
```

Đặt file `icon.png` (512×512px) vào thư mục `public/`.

---

## 📁 Cấu trúc file sau khi cập nhật

```
chance-productivity/
├── src/
│   ├── App.tsx        ← v4 (file mới)
│   ├── main.tsx
│   └── index.css
├── public/
│   └── icon.png       ← (tùy chọn, để làm PWA icon)
├── server.ts          ← v2 (file mới, có auth + sync)
├── .chance-db.json    ← tự tạo khi có user đăng ký
├── vite.config.ts     ← thêm host: true
└── package.json
```

---

## ❓ Troubleshoot

| Vấn đề | Giải pháp |
|---|---|
| Điện thoại không vào được | Kiểm tra IP đúng chưa, cùng WiFi chưa, tắt firewall laptop |
| "Không kết nối được server" | Đảm bảo `npm run dev` đang chạy trên laptop |
| Sync không hoạt động | Dùng cùng IP:3000, không phải localhost |
| Mất dữ liệu sau restart | Đồng bộ = lưu server; localStorage riêng mỗi thiết bị |
| Token hết hạn | Đăng xuất và đăng nhập lại |
